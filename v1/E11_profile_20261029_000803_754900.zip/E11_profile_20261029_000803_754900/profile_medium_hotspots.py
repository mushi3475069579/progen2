#!/usr/bin/env python3
"""Independent E11 diagnostic capture for the SCNet ProGen2-medium entry.

Run this file beside public_test.py on the DCU platform. It never edits student
code or official results. All requested B/L/G still run in full, while only the
prefill and a bounded tail of decode are traced. Timings are diagnostic only.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import traceback


SCRIPT_VERSION = 'E11-export-v2'


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--submission', type=Path, default=None)
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--loads', nargs='+', type=int, choices=[1, 2, 3, 4], default=[1, 4])
    parser.add_argument('--capture-decode', type=int, default=16)
    parser.add_argument('--cpu-only', action='store_true', help='Capture CPU scheduling while model inference still uses DCU.')
    parser.add_argument('--trace', action='store_true', help='Also export the two bounded Chrome traces per load.')
    parser.add_argument('--shapes', action='store_true', help='Record tensor shapes; increases profiler overhead.')
    args = parser.parse_args()
    if args.capture_decode < 1:
        parser.error('--capture-decode must be positive')
    return args


def save_json(path: Path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


class Tee:
    def __init__(self, original, log):
        self.original, self.log = original, log

    def write(self, text):
        self.original.write(text)
        self.log.write(text)
        self.log.flush()
        return len(text)

    def flush(self):
        self.original.flush()
        self.log.flush()


def device_us(event, field):
    value = getattr(event, field, None)
    if value is None:
        fallback = {'self_device_time_total': 'self_cuda_time_total', 'device_time_total': 'cuda_time_total'}[field]
        value = getattr(event, fallback, 0.0)
    return float(value)


def format_operator_table(events, sort_by, row_limit=35, name_width=90):
    """Format absolute times without PyTorch's full-event percentage denominators.

    A filtered list of ATen CPU events can still have attributed device times,
    but lacks raw device events used by EventList.table to compute its divisor.
    Showing absolute values avoids that assertion and preserves the raw data.
    """
    events = list(events)
    if not events:
        return 'No matching events were captured.\n'

    def metric(event, field):
        if field in {'self_device_time_total', 'device_time_total'}:
            return device_us(event, field)
        return float(getattr(event, field, 0.0))

    header = (f'{"Name":<{name_width}} {"Calls":>8} {"Self CPU ms":>13} '
              f'{"CPU total ms":>13} {"Self DCU ms":>13} {"DCU total ms":>13}')
    lines = [
        'Absolute milliseconds and call counts. No percentages are computed.',
        'CPU/device and parent/child totals overlap; do not add them as independent costs.',
        header,
        '-' * len(header),
    ]
    for event in sorted(events, key=lambda item: metric(item, sort_by), reverse=True)[:row_limit]:
        name = str(event.key)
        if len(name) > name_width:
            name = name[:name_width - 3] + '...'
        lines.append(
            f'{name:<{name_width}} {int(event.count):8d} '
            f'{metric(event, "self_cpu_time_total") / 1000:13.6f} '
            f'{metric(event, "cpu_time_total") / 1000:13.6f} '
            f'{metric(event, "self_device_time_total") / 1000:13.6f} '
            f'{metric(event, "device_time_total") / 1000:13.6f}'
        )
    return '\n'.join(lines) + '\n'


def export_capture(profiler, folder: Path, phase: str, device_requested: bool, trace: bool, shapes: bool):
    events = profiler.key_averages(group_by_input_shape=shapes)
    aten = [event for event in events if str(event.key).startswith('aten::')]
    kernels = [event for event in events if str(event.device_type).split('.')[-1].upper() == 'CUDA']
    has_device = device_requested and any(device_us(event, 'self_device_time_total') > 0 for event in events)
    # Persist all numeric rows before the human-readable tables or optional trace.
    with (folder / f'{phase}_operators.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        fields = ['name', 'device_type', 'calls', 'self_cpu_ms', 'cpu_total_ms', 'self_device_ms', 'device_total_ms', 'input_shapes']
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for event in sorted(events, key=lambda e: float(e.self_cpu_time_total), reverse=True):
            writer.writerow({
                'name': event.key, 'device_type': str(event.device_type), 'calls': event.count,
                'self_cpu_ms': float(event.self_cpu_time_total) / 1000,
                'cpu_total_ms': float(event.cpu_time_total) / 1000,
                'self_device_ms': device_us(event, 'self_device_time_total') / 1000,
                'device_total_ms': device_us(event, 'device_time_total') / 1000,
                'input_shapes': repr(event.input_shapes),
            })
    (folder / f'{phase}_cpu.txt').write_text(
        format_operator_table(events, 'self_cpu_time_total'), encoding='utf-8'
    )
    if has_device:
        (folder / f'{phase}_device.txt').write_text(
            format_operator_table(aten, 'self_device_time_total'), encoding='utf-8'
        )
        (folder / f'{phase}_kernels.txt').write_text(
            format_operator_table(kernels, 'self_device_time_total', name_width=110)
            if kernels else 'No raw device kernels were captured. Operator-attributed device times alone do not prove that the trace contains a DCU kernel timeline.\n',
            encoding='utf-8',
        )
    else:
        (folder / f'{phase}_device.txt').write_text(
            'No usable DCU activity times captured. CPU data is available; do not interpret missing device data as zero DCU cost.\n',
            encoding='utf-8',
        )
    trace_error = None
    if trace:
        try:
            profiler.export_chrome_trace(str(folder / f'{phase}_trace.json'))
        except Exception:
            trace_error = traceback.format_exc()
            (folder / f'{phase}_trace_error.txt').write_text(trace_error, encoding='utf-8')
            print(f'{phase}: trace export failed; operator tables were retained.', flush=True)
    return {'has_device_times': has_device, 'raw_device_kernel_groups': len(kernels), 'trace_export_error': trace_error,
            'table_format': 'absolute_ms_without_percentages'}


def profile_request(solution, prefixes, new_tokens, capture_decode, activities, torch, device, shapes):
    """Observe model.forward on one independent instance; restore it on all exits."""
    if new_tokens < 2:
        raise ValueError('This diagnostic expects a prefill followed by decode.')
    captured_decode = min(capture_decode, new_tokens - 1)
    decode_start = new_tokens - captured_decode
    profilers = {
        name: torch.profiler.profile(activities=activities, record_shapes=shapes, profile_memory=False, with_stack=False)
        for name in ['prefill', 'decode']
    }
    calls = 0
    active = None
    started = set()
    completed = set()
    forward = solution.model.forward
    had_instance_forward = 'forward' in solution.model.__dict__
    previous_instance_forward = solution.model.__dict__.get('forward')

    def stop_active():
        nonlocal active
        if active is not None:
            name = active
            active = None
            torch.cuda.synchronize(device)
            profilers[name].stop()
            completed.add(name)

    def observed_forward(*args, **kwargs):
        nonlocal calls, active
        index = calls
        calls += 1
        # Close prefill before the first decode, so captures cannot overlap.
        if index == 1:
            stop_active()
        if index == 0 or index == decode_start:
            name = 'prefill' if index == 0 else 'decode'
            torch.cuda.synchronize(device)
            profilers[name].start()
            active = name
            started.add(name)
        return forward(*args, **kwargs)

    solution.model.forward = observed_forward
    try:
        if hasattr(solution, 'reset'):
            solution.reset()
        outputs = solution.generate(prefixes, new_tokens)
        stop_active()
    finally:
        try:
            stop_active()
        finally:
            if had_instance_forward:
                solution.model.forward = previous_instance_forward
            else:
                delattr(solution.model, 'forward')
    if calls != new_tokens or completed != {'prefill', 'decode'}:
        raise RuntimeError(f'Expected one model forward per generated token; calls={calls}, G={new_tokens}, captured={completed}. Adapt this observer for a changed generation algorithm.')
    return outputs, profilers, {
        'actual_forward_calls': calls,
        'prefill_captured_calls': 1,
        'decode_captured_calls': captured_decode,
        'decode_start_forward_index_zero_based': decode_start,
        'uncaptured_middle_forward_calls': decode_start - 1,
        'prefill_window': 'prefill model call and selection of its next token, until the next model call',
        'decode_window': 'last model calls plus final token selection and output conversion',
    }


def run(args, folder: Path):
    root = args.root.expanduser().resolve()
    submission = (args.submission or root / 'submission').expanduser().resolve()
    spec = importlib.util.spec_from_file_location('medium_diagnostic_harness', root / 'public_test.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('Cannot load the local official test helpers.')
    harness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)
    harness.configure_runtime()
    # Import after applying the same cache directories and CPU-thread env as the official runner.
    import torch
    from tokenizers import Tokenizer

    device = torch.device(args.device)
    if device.type != 'cuda' or torch.version.hip is None or not torch.cuda.is_available():
        raise RuntimeError('Run on the contest DCU/HIP platform; --cpu-only changes tracing, not model placement.')
    supported = torch.profiler.supported_activities()
    activities = [torch.profiler.ProfilerActivity.CPU]
    device_requested = not args.cpu_only and torch.profiler.ProfilerActivity.CUDA in supported
    if device_requested:
        activities.append(torch.profiler.ProfilerActivity.CUDA)
    else:
        print('CPU tracing only. Model inference remains on the specified DCU; no full DCU hotspot claim will be made.', flush=True)

    shutil.copytree(submission, folder / 'source_snapshot', ignore=shutil.ignore_patterns('evidence', '.cache', '__pycache__', '*.pyc'))
    shutil.copy2(Path(__file__).resolve(), folder / 'profile_medium_hotspots.py')
    fingerprints = {
        str(path.relative_to(folder)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted((folder / 'source_snapshot').rglob('*')) if path.is_file() and path.suffix in {'.py', '.sh'}
    }
    save_json(folder / 'source_sha256.json', fingerprints)
    summary = {
        'script_version': SCRIPT_VERSION,
        'purpose': 'hotspot_diagnostic_not_contest_benchmark',
        'timing_for_speed_comparison': False,
        'official_results_modified': False,
        'device': torch.cuda.get_device_name(device), 'hip': torch.version.hip,
        'torch': torch.__version__, 'activities': [str(activity) for activity in activities],
        'full_requested_generation_lengths_preserved': True,
        'record_shapes': args.shapes, 'trace_requested': args.trace,
        'reference_consistency_checked': False,
        'interpretation_notes': [
            'Explicit synchronization closes each capture. Its CPU time is device waiting, not evidence of CPU arithmetic or dispatch being the bottleneck.',
            'CPU and device execution can overlap. Do not add their totals, parent/child totals, or operator-attributed device time and the same raw kernel time.',
            'Device-table percentages refer to the selected operators in that capture window, not the full official generation latency.',
            'Prefill includes next-token selection; tail decode includes final selection and output conversion. Middle steps are not captured.',
            'Profiling adds overhead. Use the independent official four-load run for performance and reference-consistency evidence.',
        ],
        'loads': [],
    }
    save_json(folder / 'summary.json', summary)
    raw = json.loads((root / 'public_test_data/public_cases.json').read_text(encoding='utf-8'))
    inputs = [{key: item[key] for key in ['id', 'batch_size', 'prefix_tokens', 'new_tokens', 'prefixes', 'warmup_prefixes']} for item in raw['loads']]
    del raw
    tokenizer = Tokenizer.from_file(str(root / 'progen2/tokenizer.json'))
    print('Loading current submission once; no official speed measurement is being performed.', flush=True)
    solution = harness.load_solution(submission, root / 'progen2/checkpoints/progen2-medium', root / 'progen2/tokenizer.json', args.device)
    for number in dict.fromkeys(args.loads):
        load = inputs[number - 1]
        batch, length, count = load['batch_size'], load['prefix_tokens'], load['new_tokens']
        for prefixes in [load['prefixes'], load['warmup_prefixes']]:
            harness.validate_prefixes(tokenizer, prefixes, batch, length)
        target = folder / load['id']
        target.mkdir()
        print(f"{load['id']}: full warmup B={batch}, L={length}, G={count}", flush=True)
        if hasattr(solution, 'reset'):
            solution.reset()
        warmup = solution.generate(load['warmup_prefixes'], count)
        harness.validate_outputs(warmup, batch, count)
        torch.cuda.synchronize(device)
        print(f"{load['id']}: capture one prefill and last {min(args.capture_decode, count-1)} decode calls; complete all G={count} steps", flush=True)
        outputs, profilers, metadata = profile_request(solution, load['prefixes'], count, args.capture_decode, activities, torch, device, args.shapes)
        harness.validate_outputs(outputs, batch, count)
        metadata.update({'load_id': load['id'], 'batch_size': batch, 'prefix_tokens': length, 'new_tokens': count, 'output_format_valid': True, 'phases': {}})
        for phase, profiler in profilers.items():
            metadata['phases'][phase] = export_capture(profiler, target, phase, device_requested, args.trace, args.shapes)
            print(f"{load['id']} {phase}: {metadata['phases'][phase]}", flush=True)
        summary['loads'].append(metadata)
        save_json(target / 'capture.json', metadata)
        save_json(folder / 'summary.json', summary)
        del profilers, warmup, outputs
    save_json(folder / 'summary.json', summary)
    (folder / 'COMPLETED.txt').write_text('Diagnostic collection finished. Check summary.json for device-data availability; this is not a benchmark or reference-consistency test.\n', encoding='utf-8')
    print('PROFILE_DONE:', folder, flush=True)
    print('Start with each load\'s decode_cpu.txt, decode_device.txt and decode_kernels.txt, then compare prefill files.', flush=True)


def main():
    args = arguments()
    root = args.root.expanduser().resolve()
    if not (root / 'public_test.py').is_file():
        raise SystemExit('Place this script in the contest root beside public_test.py, or pass --root.')
    folder = root / 'results' / ('E11_profile_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    folder.mkdir(parents=True, exist_ok=False)
    original_out, original_err = sys.stdout, sys.stderr
    with (folder / 'profile.log').open('w', encoding='utf-8') as log:
        sys.stdout, sys.stderr = Tee(original_out, log), Tee(original_err, log)
        try:
            print('PROFILE_OUTPUT:', folder, flush=True)
            print('PROFILE_SCRIPT_VERSION:', SCRIPT_VERSION, flush=True)
            run(args, folder)
        except Exception:
            error = traceback.format_exc()
            (folder / 'error.txt').write_text(error, encoding='utf-8')
            print(error, file=sys.stderr, flush=True)
            print('Diagnostic failed. Keep this folder. Official E10 results and submission source were not changed.', file=sys.stderr, flush=True)
            return 1
        finally:
            sys.stdout, sys.stderr = original_out, original_err
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
